const config = {
  "token": "Nzg1MTkxMDk4NTczOTE0MTEy.X80QMg.ZYQdy58y_1cib7goLjSbc5Zoahs",
  "dashboard" : {
    "oauthSecret": "WPiL_fsO9lYjX1DgTf1QMgJ8sL5l7pI2",
    "callbackURL": `https://receptive-secretive-seaplane.glitch.me/callback`,
    "sessionSecret": "super-secret-session-thing",
    "domain": "https://receptive-secretive-seaplane.glitch.me/",
     "port": 8000
  }
};
